package vrwjg;

import java.lang.reflect.Field;

import zombie.ui.RadialMenu;
import zombie.ui.UIElementInterface;
import zombie.ui.UIManager;

public final class WheelCursor {
    private static Field wantCapture;

    private WheelCursor() {}

    public static void apply() {
        if (!wheelVisible()) return;
        Field field = field();
        if (field == null) return;
        try {
            field.setBoolean(null, false);
        } catch (Throwable ignored) {
        }
    }

    private static Field field() {
        if (wantCapture != null) return wantCapture;
        try {
            wantCapture = Class.forName("viewpoint.input.Look").getField("wantCapture");
        } catch (Throwable ignored) {
        }
        return wantCapture;
    }

    private static boolean wheelVisible() {
        for (UIElementInterface element : UIManager.UI) {
            if (element instanceof RadialMenu && ((RadialMenu) element).isReallyVisible()) {
                return true;
            }
        }
        return false;
    }
}
