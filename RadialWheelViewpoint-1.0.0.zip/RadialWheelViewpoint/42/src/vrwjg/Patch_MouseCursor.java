package vrwjg;

import me.zed_0xff.zombie_buddy.Patch;

@Patch(className = "viewpoint.input.Look", methodName = "onUpdateMouseCursor", warmUp = true)
public final class Patch_MouseCursor {
    @Patch.OnEnter
    public static void enter() {
        WheelCursor.apply();
    }
}
