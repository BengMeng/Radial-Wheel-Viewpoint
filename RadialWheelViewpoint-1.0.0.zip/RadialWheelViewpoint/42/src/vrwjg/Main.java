package vrwjg;

public final class Main {
    public static void main(String[] args) {
        System.out.println("[VRWJG] Viewpoint radial wheel (By JG) v1.0 loaded");
    }
}
