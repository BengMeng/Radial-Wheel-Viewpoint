-- Viewpoint Radial Wheel (By JG)
-- Hold a radial-wheel key to open the vanilla wheel, move the now-free mouse
-- over a slice, release the key and that slice runs.

local R = {
    visible = false,
    key = nil,
}

local WHEEL_BINDS = {
    KeybindId.VEHICLE_RADIAL_MENU,
    KeybindId.ANIMAL_RADIAL_MENU,
    KeybindId.EMOTE,
    KeybindId.SHOUT,
    KeybindId.LIGHT_SOURCE,
    KeybindId.RELOAD_WEAPON,
    KeybindId.HOTBAR_1,
    KeybindId.HOTBAR_2,
    KeybindId.HOTBAR_3,
    KeybindId.HOTBAR_4,
    KeybindId.HOTBAR_5,
    KeybindId.HOTBAR_6,
    KeybindId.HOTBAR_7,
    KeybindId.HOTBAR_8,
}

local function heldWheelKey()
    -- GameKeyboard uses 256 legacy key slots, not GLFW's key range.
    for code = 0, 255 do
        if isKeyDown(code) then
            for i = 1, #WHEEL_BINDS do
                if getCore():isKey(WHEEL_BINDS[i], code) then
                    return code
                end
            end
        end
    end
    return nil
end

local function onPlayerUpdate(player)
    if not player or player:getPlayerNum() ~= 0 then return end
    local menu = getPlayerRadialMenu(0)
    local visible = menu and menu:isReallyVisible() or false
    if visible and not R.visible then
        if not menu.joyfocus and not getCore():getOptionRadialMenuKeyToggle() then
            R.key = heldWheelKey()
        end
        if R.key then
            print("[VRWJG] wheel open, select on release of key " .. tostring(R.key))
        end
    elseif not visible then
        R.key = nil
    end
    R.visible = visible
end

local function onKeyPressed(key)
    if not R.key or key ~= R.key then return end
    R.key = nil
    R.visible = false
    local menu = getPlayerRadialMenu(0)
    if not menu or not menu:isReallyVisible() or menu.joyfocus then return end
    if getCore():getOptionRadialMenuKeyToggle() then return end
    local hotbar = getPlayerHotbar(0)
    if hotbar and hotbar:getSlotForKey(key) ~= -1 then
        -- Vanilla must not treat this release as a second, tap-to-equip action.
        hotbar.radialWasVisible = true
    end
    local x = math.floor(Mouse.getXA() - menu:getAbsoluteX())
    local y = math.floor(Mouse.getYA() - menu:getAbsoluteY())
    local index = menu.javaObject:getSliceIndexFromMouse(x, y)
    print("[VRWJG] release key " .. tostring(key) .. ", slice " .. tostring(index))
    menu:onMouseDown(x, y)
end

Events.OnPlayerUpdate.Add(onPlayerUpdate)
Events.OnKeyPressed.Add(onKeyPressed)

print("[VRWJG] Viewpoint radial wheel (By JG) v1.0 lua ready")
